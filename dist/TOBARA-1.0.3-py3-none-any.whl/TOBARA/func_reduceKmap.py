# Actualizado 23 de Mayo 2020
# Función en proceso
def reduceKmap( kmap ):
	
	active = kmap
