<p align="center">
  <img src="https://github.com/MiguelRAvila/projectTOBARA/blob/master/images/logo.png?raw=true" alt="TOBARALogo"/>
  
  <h3 > projectTOBARA: The Only Boolean Algebra Reduction App</h3>
</p>
<a href='#'><img src='https://img.shields.io/badge/python-3.6-blue.svg'>
</a> 

[![Inline docs](http://inch-ci.org/github/dwyl/hapi-auth-jwt2.svg?branch=master)](#)

projctTOBARA is a toolkit of Boolean function analysis whose main task is to reduce Boolean functions as much as possible. Our objetive is to determine information about the function like variables, terms and then reduce the function.  

* [Quick Stat Guide](#)
* [Documentation](#)


## Installation

Make sure you have Python 3.6 or newer.
You can install it with pip:


## Docs

projectTOBARA documentation is available here:
* [Documentation](#)

## Quick Start Guide


